'use client'

import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Edit2, Trash2, Eye, EyeOff, Shield, AlertTriangle, X } from 'lucide-react'

interface Helper {
  id: string
  username: string
  display_name: string
  created_at: string
}

export default function AdminHelpersPage() {
  const [helpers, setHelpers] = useState<Helper[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [selectedId, setSelectedId] = useState<string | null>(null)

  // Form states
  const [form, setForm] = useState({ username: '', display_name: '', password: '' })
  const [formError, setFormError] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [showPass, setShowPass] = useState(false)

  // Delete states
  const [deleteTarget, setDeleteTarget] = useState<Helper | null>(null)
  const [deleting, setDeleting] = useState(false)

  async function loadHelpers() {
    try {
      const res = await fetch('/api/admin/helpers')
      if (res.ok) {
        const data = await res.json()
        setHelpers(data.helpers || [])
      }
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadHelpers()
  }, [])

  function openCreate() {
    setIsEditing(false)
    setSelectedId(null)
    setForm({ username: '', display_name: '', password: '' })
    setFormError('')
    setShowPass(false)
    setShowModal(true)
  }

  function openEdit(h: Helper) {
    setIsEditing(true)
    setSelectedId(h.id)
    setForm({ username: h.username, display_name: h.display_name, password: '' })
    setFormError('')
    setShowPass(false)
    setShowModal(true)
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setFormError('')

    if (!form.username.trim() || !form.display_name.trim()) {
      setFormError('Username and Display Name are required.')
      return
    }

    if (!isEditing && (!form.password || form.password.length < 4)) {
      setFormError('Password must be at least 4 characters.')
      return
    }

    if (isEditing && form.password && form.password.length < 4) {
      setFormError('New password must be at least 4 characters.')
      return
    }

    setSubmitting(true)
    try {
      const url = '/api/admin/helpers'
      const method = isEditing ? 'PATCH' : 'POST'
      const body = isEditing 
        ? { id: selectedId, username: form.username.trim(), display_name: form.display_name.trim(), password: form.password || undefined }
        : { username: form.username.trim(), display_name: form.display_name.trim(), password: form.password }

      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      })

      if (res.ok) {
        setShowModal(false)
        loadHelpers()
      } else {
        const errData = await res.json().catch(() => ({}))
        setFormError(errData.error || 'Something went wrong.')
      }
    } catch {
      setFormError('Network error. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  async function handleDelete() {
    if (!deleteTarget) return
    setDeleting(true)
    try {
      const res = await fetch(`/api/admin/helpers?id=${deleteTarget.id}`, { method: 'DELETE' })
      if (res.ok) {
        setHelpers(prev => prev.filter(h => h.id !== deleteTarget.id))
        setDeleteTarget(null)
      }
    } catch (e) {
      console.error(e)
    } finally {
      setDeleting(false)
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white p-4 sm:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-extrabold tracking-tight flex items-center gap-2">
              <Shield className="w-6 h-6 text-blue-500" /> Survey Helpers
            </h1>
            <p className="text-white/40 text-sm mt-1">Manage agent accounts authorized to collect survey data.</p>
          </div>
          <button
            type="button"
            onClick={openCreate}
            className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-500 active:scale-95 transition-all px-4 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-blue-600/10"
          >
            <Plus className="w-4 h-4" /> Add Helper Account
          </button>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-16 w-full bg-white/5 border border-white/5 animate-pulse rounded-xl" />
            ))}
          </div>
        ) : helpers.length > 0 ? (
          <div className="border border-white/10 rounded-2xl overflow-hidden bg-white/5 backdrop-blur-md">
            <div className="divide-y divide-white/10">
              {helpers.map(h => (
                <div key={h.id} className="flex items-center justify-between p-4 sm:p-5 hover:bg-white/5 transition-colors">
                  <div className="min-w-0 flex-1 pr-4">
                    <div className="font-bold text-base truncate">{h.display_name}</div>
                    <div className="text-sm text-white/40 font-mono mt-0.5">@{h.username}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => openEdit(h)}
                      className="p-2 rounded-xl bg-white/5 border border-white/10 hover:text-blue-400 hover:bg-blue-500/10 transition-all"
                      title="Edit Account"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleteTarget(h)}
                      className="p-2 rounded-xl bg-white/5 border border-white/10 hover:text-red-400 hover:bg-red-500/10 transition-all"
                      title="Delete Account"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="text-center py-16 bg-white/5 border border-white/10 border-dashed rounded-2xl text-white/30">
            <Shield className="w-12 h-12 mx-auto mb-3 opacity-20" />
            <p className="text-sm font-medium">No helper accounts configured yet</p>
            <p className="text-xs mt-1">Click the button above to add your first user.</p>
          </div>
        )}
      </div>

      {/* CREATE & EDIT MODAL */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="w-full max-w-md bg-slate-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden"
            >
              <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
                <h2 className="font-bold text-lg">{isEditing ? 'Edit Helper' : 'Add Helper Account'}</h2>
                <button type="button" onClick={() => setShowModal(false)} className="text-white/40 hover:text-white p-1">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="p-6 space-y-4">
                {formError && (
                  <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-sm flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span>{formError}</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-white/50 mb-1.5">Display Name</label>
                  <input
                    type="text"
                    value={form.display_name}
                    onChange={e => { setForm(p => ({ ...p, display_name: e.target.value })); setFormError('') }}
                    placeholder="e.g. John Doe"
                    className="w-full p-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/25 outline-none focus:border-blue-500 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-white/50 mb-1.5">Login Username</label>
                  <input
                    type="text"
                    value={form.username}
                    onChange={e => { setForm(p => ({ ...p, username: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '') })); setFormError('') }}
                    placeholder="e.g. john_doe"
                    disabled={isEditing}
                    className="w-full p-3 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/25 outline-none focus:border-blue-500 transition-colors disabled:opacity-50 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-white/50 mb-1.5">Account Password</label>
                  <div className="relative">
                    <input
                      type={showPass ? 'text' : 'password'}
                      value={form.password}
                      onChange={e => { setForm(p => ({ ...p, password: e.target.value })); setFormError('') }}
                      placeholder={isEditing ? 'Leave blank to keep current password' : 'Password (min 4 chars)'}
                      className="w-full p-3 pr-10 rounded-xl bg-white/5 border border-white/10 text-white placeholder:text-white/25 outline-none focus:border-blue-500 transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPass(p => !p)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white transition-colors"
                    >
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-white/70 hover:text-white font-semibold text-sm transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 font-semibold text-sm text-white disabled:opacity-50 shadow-lg shadow-blue-600/10 transition-all"
                  >
                    {submitting ? 'Saving…' : 'Save Account'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* DELETE CONFIRM MODAL */}
      <AnimatePresence>
        {deleteTarget && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-white/10 rounded-2xl p-6 max-w-sm w-full shadow-2xl"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center flex-shrink-0">
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                </div>
                <div>
                  <h3 className="font-bold text-white">Delete Account?</h3>
                  <p className="text-white/40 text-xs">This action cannot be undone.</p>
                </div>
              </div>
              <p className="text-white/60 text-sm mb-6">
                Are you sure you want to completely delete the helper account for <strong className="text-white">{deleteTarget.display_name}</strong>? They will immediately lose survey system login access.
              </p>
              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => setDeleteTarget(null)}
                  disabled={deleting}
                  className="flex-1 py-3 rounded-xl bg-white/5 border border-white/10 text-white/70 font-semibold text-sm transition-colors disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDelete}
                  disabled={deleting}
                  className="flex-1 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-semibold text-sm transition-colors disabled:opacity-50"
                >
                  {deleting ? 'Deleting…' : 'Delete'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  )
}